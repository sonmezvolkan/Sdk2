//
//  SecureSdk.h
//  SecureSdk
//
//  Created by Volkan Sönmez on 28.08.2023.
//

#import <Foundation/Foundation.h>

//! Project version number for SecureSdk.
FOUNDATION_EXPORT double SecureSdkVersionNumber;

//! Project version string for SecureSdk.
FOUNDATION_EXPORT const unsigned char SecureSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SecureSdk/PublicHeader.h>


